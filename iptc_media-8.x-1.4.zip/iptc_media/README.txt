"IPTC Media" 
